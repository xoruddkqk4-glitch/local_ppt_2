﻿pink-script — 슬라이드 디자인 묶음
==============================

들어 있는 것
- deck.html        : 이 디자인으로 만든 예시 덱(6장: 표지 / 흐름 / 숫자와 그래프 / 비교와 표 / 확인하기 / 디자인 안내(대표 장치 시연)). 브라우저로 열면 됩니다.
- design.md        : 템플릿 디자인 명세(색·글꼴·배치·장식·움직임). AI에게 이 파일을 주면 같은 디자인으로 새 덱을 만들 수 있습니다.
- fonts/           : 예시 덱에 쓴 한글 폰트 원본 파일
- README.txt       : 이 안내문(아래에 폰트·디자인 명세 라이선스 문구가 들어 있습니다)

한글 폰트 짝
- 제목: Noto Serif KR Black (900)
- 본문: Noto Sans KR Thin (100)

AI에게 새 덱을 만들게 할 때
구성은 내용이 정합니다 (예시 덱을 베끼지 마세요)
- 예시 덱(deck.html)은 이 디자인의 부품 견본입니다. 따라야 할 장 구성이 아닙니다. 예시의 장 순서·장 수·제목 짜임·문장 구조를 그대로 따라 하지 마세요.
- 사용자가 준 내용을 먼저 살펴 필요한 장 수와 장별 역할을 직접 정하세요. 내용이 적으면 3~4장, 많으면 8장 이상도 괜찮습니다.
- 코드를 쓰기 전에 장별 구성안(장마다 제목 · 전할 내용 한 줄 · 쓸 부품)을 먼저 보여 주고 확인을 받으세요. 사용자가 고치라고 하면 고친 구성안을 다시 보여 주고, "좋아", "만들어 줘"라고 하면 그때 만듭니다. 사용자가 처음부터 "구성 확인 없이 바로 만들어 줘"라고 했으면 이 단계는 건너뜁니다.
- 아래 부품 중 필요한 것만 골라 쓰세요. 안 쓰는 부품이 있어도 되고(예: 퀴즈 없는 덱), 같은 부품을 여러 장에 쓰거나 한 장에 섞어 써도 됩니다.
  · 표지 · 단계 버튼이 있는 흐름(data-steps) · 큰 숫자와 통계 · 그래프 · 비교와 표 · 목록과 인용 · 퀴즈와 다시 풀기 · 빈칸 채우기 · 시연 버튼(data-demo)
- 장마다 전하는 메시지는 하나로 하고, 같은 모양의 장이 연달아 나오지 않게 하세요.
- 지켜야 하는 것은 디자인 규칙(design.md)과 동작 엔진입니다. 자유로운 것은 장의 수·순서·구성입니다.
- 요청 예시: "이 폴더의 design.md 규칙과 deck.html의 부품·엔진을 쓰되, deck.html의 장 구성은 따라 하지 말고 내 수업 내용에 맞게 장 수와 구성을 새로 정해서 슬라이드를 만들어 줘. 수업 내용: …"

조작
- → ↓ Space: 다음(단계 버튼이 있는 장은 단계가 먼저 넘어감), ← ↑: 이전, Home/End: 처음/끝
- 주소 끝에 #2 를 붙이면 2장부터 열림

알아 둘 점
- 영문 글꼴(DM Serif Display, Inter, JetBrains Mono)은 Google Fonts에서 불러오므로 인터넷이 필요합니다.
- 한글 폰트는 먼저 이 묶음의 fonts/ 폴더에서 불러오고, 없으면 인터넷의 폰트 창고(https://maker-ssam.github.io/korean-ofl-fonts/)에서 불러옵니다. 인터넷 없이 쓰려면 deck.html(또는 이것으로 만든 새 html)과 fonts/ 폴더를 같은 위치에 두세요. html만 다른 곳으로 옮겨도 인터넷이 되면 글씨체가 유지됩니다.
- AI가 새 덱을 만들 때는 deck.html의 @font-face 줄(fonts/ 파일 → 인터넷 주소 순서)을 그대로 쓰게 하세요.
- fonts/의 파일은 원본(전체 글자)이라 용량이 큽니다. 발표용으로 가볍게 만들려면 쓴 글자만 남기는 서브셋 작업을 따로 하세요.

폰트 라이선스 안내
==================

- Noto Serif KR Black: Noto Serif KR — [합침 2026-10-07] 같은 가족의 폴더를 이 폴더로 합침 / --- NotoSerifCJKKR ---
  파일: NotoSerifKR-Black.ttf
- Noto Sans KR Thin: Noto Sans KR — KERIS 학교 안심폰트(https://copyright.keris.or.kr/wft/fntDwnld, 전체 OFL 안내)에서 받은 TTF (2026-10-07) / 파일 안 저작권: (c) 2014-2021 Adobe (http://www.adobe.com/), with Reserved Font Name 'Source'.
  파일: NotoSansKR-Thin.ttf

SIL Open Font License 1.1 요약
- 폰트를 자유롭게 사용·복제·수정·재배포할 수 있습니다(폰트 파일 단독 판매는 불가).
- 수정본(글자를 줄인 서브셋 포함)은 원래 폰트의 '예약 이름'을 쓰지 못할 수 있습니다.
- 재배포할 때는 저작권 표시와 라이선스 문구를 함께 넣어야 합니다.
- 전문: https://openfontlicense.org

학교안심 글꼴과 easy3D 폴더의 글꼴은 사용자가 OFL로 확인한 내용을 따랐습니다. 배포 전에 각 배포처에서 최신 라이선스를 다시 확인하세요.

design.md 라이선스 (MIT)
=======================
design.md는 frontend-slides(https://github.com/zarazhangrui/frontend-slides)의 템플릿을 바탕으로 한 것이며, 아래 MIT 라이선스를 따릅니다.

MIT License

Copyright (c) 2025 Zara Zhang

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
